export const geoApiOptions = {
  method: "GET",
  headers: {
    "X-RapidAPI-Key": "60769c49eamshba720019b298529p17f941jsnd8b4ff725438",
    "X-RapidAPI-Host": "wft-geo-db.p.rapidapi.com",
  },
};
export const GEO_API_URL = "https://wft-geo-db.p.rapidapi.com/v1/geo";

export const WEATHER_API_URL = "https://api.openweathermap.org/data/2.5";
export const WEATHER_API_KEY = "521e9890226bd8c1d4ab56d3dd73b3fe"; 